import 'package:flutter/material.dart';

class SubmitReportPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Submit Report'),
      ),
      body: Center(
        child: Text('Submit Report Page'),
      ),
    );
  }
}
