import 'package:flutter/material.dart';

class PricingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pricing'),
      ),
      body: Center(
        child: Text('Pricing Page'),
      ),
    );
  }
}
