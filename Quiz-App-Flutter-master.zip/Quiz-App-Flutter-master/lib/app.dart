import 'package:flutter/material.dart';


class RadiXGPTApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RadiXGPT',
      theme: appTheme,
      home: HomePage(),
    );
  }
}
